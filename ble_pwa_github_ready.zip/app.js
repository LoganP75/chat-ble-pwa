async function scanBLE() {
  try {
    const options = { acceptAllDevices: true, optionalServices: ['battery_service'] };
    const device = await navigator.bluetooth.requestDevice(options);
    document.getElementById("devices").innerHTML = `<li>📡 Nom: ${device.name || 'Inconnu'}<br>ID: ${device.id}</li>`;
  } catch (error) {
    alert("Erreur: " + error);
  }
}

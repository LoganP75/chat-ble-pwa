# Scanner BLE PWA

Cette application Web (PWA) permet de scanner les appareils Bluetooth Low Energy (BLE) à proximité directement depuis un navigateur compatible.

## Fonctionnalités
- Scan des périphériques BLE
- Interface simple HTML/JS
- Compatible avec l'installation PWA (mobile)
- Hébergable gratuitement via GitHub Pages

## Déploiement GitHub Pages
1. Crée un dépôt GitHub
2. Téléverse ces fichiers
3. Active GitHub Pages dans Settings > Pages > Branch: main > Folder: root
